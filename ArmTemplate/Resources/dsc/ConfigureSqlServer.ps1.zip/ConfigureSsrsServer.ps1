#
# Copyright="� Microsoft Corporation. All rights reserved."
#
configuration ConfigureSsrsServer
{
    param
    (

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLAuthAdmincreds,

	[Parameter(Mandatory)]
        [String]$CatalogMachine
    )

    Import-DscResource -ModuleName xComputerManagement, xActiveDirectory,xSQLServer,xNetworking,xPSDesiredStateConfiguration

    Node localhost
    {   
	
		xSQLServerRSConfig RSServer
		{
			InstanceName = "MSSQLSERVER"
			RSSQLServer = $CatalogMachine
			RSSQLInstanceName = "MSSQLSERVER"
			SQLAdminCredential = $SQLAuthAdmincreds
		}
		
		xService MSSQLSERVER
		{
			Name = "MSSQLSERVER"
			Startuptype = "Manual"
			State = "Stopped"
		}
       
    }
}
