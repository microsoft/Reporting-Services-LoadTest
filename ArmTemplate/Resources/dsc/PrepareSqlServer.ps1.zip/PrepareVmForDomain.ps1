﻿#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration PrepareVmForDomain
{

    param
    (
        [Parameter(Mandatory)]
        [String]$DNSServer,
        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=60
    )

    Import-DscResource -ModuleName xComputerManagement, xNetworking, xDisk,cDisk
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
        xFirewall SSRSHTTP
        {
            Direction = "Inbound"
            Name = "SSRS-Server-HTTP-TCP-In"
            DisplayName = "SQL Server Reporting Services (TCP-In)"
            Description = "Inbound rule for to allow http traffic to SSRS"
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "80"
            Ensure = "Present"
        }
		xFirewall SSRSHTTPs
        {
            Direction = "Inbound"
            Name = "SSRS-Server-HTTPs-TCP-In"
            DisplayName = "SQL Server Reporting Services ssl (TCP-In)"
            Description = "Inbound rule for to allow https traffic to SSRS"
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "443"
            Ensure = "Present"
        }
        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
        xDnsServerAddress DnsServerAddress
        {
            Address        = $DNSServer
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn="[WindowsFeature]ADPS"
        }

    }
}
